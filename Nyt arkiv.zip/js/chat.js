// Kilde for chat: W3 schools, (n.d), “How to create a popup chat window”, https://www.w3schools.com/howto/howto_js_popup_chat.asp, (set online d. 24/05-2022)

function openForm() {
    document.getElementById("myForm").style.display = "block";
  }
  
  function closeForm() {
    document.getElementById("myForm").style.display = "none";
  }