# Mystackeksamen
2.semesters eksamen
